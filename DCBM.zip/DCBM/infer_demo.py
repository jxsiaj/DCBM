# @title Set-up model. { run: "auto" }
from PIL import Image
from tqdm import tqdm

import cv2
import numpy as np

from visual import process


class VideoDataset:
    def __init__(self, paths, interval=0.5):
        self.dataset = cv2.VideoCapture(paths)
        self.count = int(self.dataset.get(cv2.CAP_PROP_FRAME_COUNT))
        self.fps = self.dataset.get(cv2.CAP_PROP_FPS)
        self.interval = interval
        self.frame_interval = int(self.fps * self.interval)

    def __iter__(self):
        self.current_frame = 0
        return self

    def __len__(self):
        return self.count // self.frame_interval

    def __next__(self):
        self.dataset.set(cv2.CAP_PROP_POS_FRAMES, self.current_frame)
        ret, frame = self.dataset.read()
        if not ret:
            raise StopIteration
        self.current_frame += self.frame_interval
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        origin_frame = np.array(Image.fromarray(frame).convert('RGB'))
        frame = Image.fromarray(frame).convert('RGB')
        return frame, origin_frame

    def get_video_size(self):
        return int(self.dataset.get(cv2.CAP_PROP_FRAME_WIDTH)), int(self.dataset.get(cv2.CAP_PROP_FRAME_HEIGHT))

    def get_video_fps(self):
        return self.fps

def process_video(datasets,qt_progress_bar):
    # fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    # out = cv2.VideoWriter("output.mp4", fourcc, 30, datasets.get_video_size())
    result = []
    for (img, origin_img) in tqdm(datasets):
        result_label, result_frame = process(img)
        result.append((result_label, result_frame))
        qt_progress_bar.emit(int(datasets.current_frame / datasets.count * 100))
        # out.write(cv2.cvtColor(np.array(result_frame), cv2.COLOR_BGR2RGB))
    return result
    # out.release()


