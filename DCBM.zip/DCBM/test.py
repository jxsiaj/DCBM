import os

import torchvision.transforms.functional

# 假设 dirpath 是你要遍历的目录路径
dirpath = '/home/charlotte/Desktop/故障照片/label'
replace_label = '4'
# 遍历目录
for dirpath, dirnames, filenames in os.walk(dirpath):
    for filename in filenames:
        # 构建文件的绝对路径
        abs_path = os.path.join(dirpath, filename)

        # 读取文件内容
        with open(abs_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        # 修改每行的第一个字符为 '0'
        modified_lines = [replace_label + line[1:] if line else replace_label for line in lines]

        # 将修改后的内容写回文件
        with open(abs_path, 'w', encoding='utf-8') as file:
            file.writelines(modified_lines)

print("所有文件的第一个字符已被替换为" + replace_label)