from PySide6.QtWidgets import QMainWindow


class DetectApp:
    def __init__(self):
        self.window = QMainWindow()
        self.window.setWindowTitle("检测")
        self.window.resize(800, 600)
        # self.window.show()

        