import math
import random

import PIL
import numpy as np
import torch
from PIL import Image

from yolov6.data.data_augment import letterbox
from yolov6.layers.common import DetectBackend
from yolov6.utils.events import load_yaml
from yolov6.utils.nms import non_max_suppression
from yolov6.core.inferer import Inferer

from typing import List, Optional

checkpoint: str = "yolov6s"  # @param ["yolov6s", "yolov6n", "yolov6t"]
device: str = "gpu"  # @param ["gpu", "cpu"]
half: bool = False  # @param {type:"boolean"}

cuda = device != 'cpu' and torch.cuda.is_available()
device = torch.device('cuda:0' if cuda else 'cpu')

model = DetectBackend(f"./weights/best_ckpt.pt", device=device)
stride = model.stride
class_names = load_yaml("data/ours.yaml")['names']

from GUI import CLASS_MAP
# return model, stride, class_names
if half & (device.type != 'cpu'):
    model.model.half()
else:
    model.model.float()
    half = False

if device.type != 'cpu':
    model(torch.zeros(1, 3, *(640, 640)).to(device).type_as(next(model.model.parameters())))  # warmup


def process(img, qt_progress_bar=None):
    # url: str = "C:/Users/Charlotte/Desktop/tmpbwvxal7g.jpg"  # @param {type:"string"}
    hide_labels: bool = False  # @param {type:"boolean"}
    hide_conf: bool = False  # @param {type:"boolean"}

    img_size: int = 640  # @param {type:"integer"}

    conf_thres: float = .25  # @param {type:"number"}
    iou_thres: float = .45  # @param {type:"number"}
    max_det: int = 1000  # @param {type:"integer"}
    agnostic_nms: bool = False  # @param {type:"boolean"}

    img_size = check_img_size(img_size, s=stride)
    label = None
    if qt_progress_bar is not None:
        qt_progress_bar.emit(random.randint(0, 10))
    img, img_src = process_image(img, img_size, stride, half)
    img = img.to(device)
    if len(img.shape) == 3:
        img = img[None]
        # expand for batch dim
    if qt_progress_bar is not None:
        qt_progress_bar.emit(random.randint(11, 25))
    pred_results = model(img)
    if qt_progress_bar is not None:
        qt_progress_bar.emit(random.randint(26, 75))
    classes: Optional[List[int]] = None  # the classes to keep
    det = non_max_suppression(pred_results, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det)[0]
    if qt_progress_bar is not None:
        qt_progress_bar.emit(random.randint(76, 99))
    gn = torch.tensor(img_src.shape)[[1, 0, 1, 0]]  # normalization gain whwh
    img_ori = img_src.copy()
    all_labels = []
    if len(det):
        det[:, :4] = Inferer.rescale(img.shape[2:], det[:, :4], img_src.shape).round()
        for *xyxy, conf, cls in reversed(det):
            class_num = int(cls)
            label = None if hide_labels else (
                CLASS_MAP[class_names[class_num]] if hide_conf else f'{CLASS_MAP[class_names[class_num]]} {conf:.2f}')
            all_labels.append((class_names[class_num], conf))
            Inferer.plot_box_and_label(img_ori, max(round(sum(img_ori.shape) / 2 * 0.003), 2), xyxy, label,
                                       color=Inferer.generate_colors(class_num, True))
    if qt_progress_bar is not None:
        qt_progress_bar.emit(100)

    return all_labels ,Image.fromarray(img_ori)



def check_img_size(img_size, s=32, floor=0):
    def make_divisible(x, divisor):
        # Upward revision the value x to make it evenly divisible by the divisor.
        return math.ceil(x / divisor) * divisor

    """Make sure image size is a multiple of stride s in each dimension, and return a new shape list of image."""
    if isinstance(img_size, int):  # integer i.e. img_size=640
        new_size = max(make_divisible(img_size, int(s)), floor)
    elif isinstance(img_size, list):  # list i.e. img_size=[640, 480]
        new_size = [max(make_divisible(x, int(s)), floor) for x in img_size]
    else:
        raise Exception(f"Unsupported type of img_size: {type(img_size)}")

    if new_size != img_size:
        print(f'WARNING: --img-size {img_size} must be multiple of max stride {s}, updating to {new_size}')
    return new_size if isinstance(img_size, list) else [new_size] * 2


def process_image(path, img_size, stride, half):
    '''Process image before image inference.'''
    if isinstance(path, PIL.Image.Image):
        img_src = np.array(path)
        assert path is not None, f'Invalid image: {path}'
    else:
        try:
            from PIL import Image
            img_src = np.asarray(Image.open(path).convert('RGB'))
            assert img_src is not None, f'Invalid image: {path}'
        except Exception as e:
            print(f'Invalid image: {path}')

    image = letterbox(img_src, img_size, stride=stride)[0]

    # Convert
    image = image.transpose((2, 0, 1))  # HWC to CHW
    image = torch.from_numpy(np.ascontiguousarray(image))
    image = image.half() if half else image.float()  # uint8 to fp16/32
    image /= 255  # 0 - 255 to 0.0 - 1.0

    return image, img_src
